# Deploy ADL Intelligence to the Web — 5-Minute Guide

Anyone with the link can open the dashboard in their browser.
No Python. No install. Works on Mac, Windows, iPad, phone.

---

## Step 1 — Create a GitHub Account (2 min)

1. Go to https://github.com
2. Click **Sign up** — use your Hult email
3. Verify your email

---

## Step 2 — Create a New Repository (1 min)

1. Click the **+** icon (top right) → **New repository**
2. Name it: `adl-intelligence`
3. Set to **Public** ← required for free Streamlit hosting
4. Click **Create repository**

---

## Step 3 — Upload Files (2 min)

On your new repository page, click **uploading an existing file**

Upload ALL of these (drag and drop the entire adl_app_package folder contents):

```
adl_dashboard_v3.py
requirements.txt
.streamlit/config.toml
data/career_search_trends.csv
data/trends_firm_careers.csv
data/trends_consulting_vs_ai.csv
data/trends_skill_demand.csv
data/trends_junior_experience.csv
data/ADL_Alumni_Career_Destinations.xlsx
data/Consulting_Entry_Level_Headcount_Analysis.xlsx
```

Click **Commit changes**

---

## Step 4 — Deploy on Streamlit Cloud (1 min)

1. Go to https://share.streamlit.io
2. Click **Sign in with GitHub**
3. Click **New app**
4. Select your repository: `adl-intelligence`
5. Main file path: `adl_dashboard_v3.py`
6. Click **Deploy**

Streamlit builds it (takes ~2 minutes). You get a URL like:
```
https://husnarafi-adl-intelligence.streamlit.app
```

---

## Step 5 — Share the URL

Send this URL to ADL partners. They click it. Done.

You can also embed it in your D6 submission document.

---

## Notes

- The app stays live as long as your GitHub repo exists
- Free tier: sleeps after 7 days of no visits, wakes in ~30 seconds when someone visits
- To keep it always awake: Streamlit Community Cloud settings → "Always on" (paid tier, $25/mo)
- To update the dashboard: re-upload `adl_dashboard_v3.py` to GitHub → Streamlit rebuilds automatically

---

## If the Upload Step Is Confusing

Install GitHub Desktop (https://desktop.github.com) — drag and drop the folder, click Publish.

---

*Built by Husna Rafi · Hult MBA Capstone 2026*
