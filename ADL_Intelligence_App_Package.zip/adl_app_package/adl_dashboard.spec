# ADL Intelligence Dashboard — PyInstaller Spec
# Works for both Mac (.app) and Windows (.exe)
#
# Build commands:
#   Mac:     pyinstaller adl_dashboard.spec
#   Windows: pyinstaller adl_dashboard.spec
#
# Output:
#   Mac:     dist/ADL Intelligence.app
#   Windows: dist/ADL Intelligence/ADL Intelligence.exe

import sys
import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

# ── Collect Streamlit's static files and templates ──────────────────────────
streamlit_datas = collect_data_files("streamlit")

# ── Collect altair, plotly, pandas etc. ─────────────────────────────────────
plotly_datas    = collect_data_files("plotly")

# ── Hidden imports Streamlit needs ────────────────────────────────────────────
hidden = (
    collect_submodules("streamlit") +
    collect_submodules("pandas") +
    collect_submodules("plotly") +
    collect_submodules("numpy") +
    collect_submodules("openpyxl") +
    [
        "streamlit.web.cli",
        "streamlit.runtime.scriptrunner.magic_funcs",
        "pkg_resources.py2_warn",
        "pyarrow",
        "pyarrow.lib",
        "pyarrow.vendored.version",
    ]
)

# ── Data files bundled with the app ──────────────────────────────────────────
datas = streamlit_datas + plotly_datas + [
    # Data folder — copy the whole data/ subfolder into the bundle
    ("data", "data"),
    # The dashboard script itself
    ("adl_dashboard_v3.py", "."),
]

a = Analysis(
    ["launcher.py"],
    pathex=["."],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["matplotlib", "tkinter", "PyQt5", "wx", "IPython", "jupyter"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=None,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

# ── Single executable (onefile) ──────────────────────────────────────────────
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="ADL Intelligence",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # No terminal window
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # Windows icon (optional — add adl_icon.ico if you have one)
    # icon="adl_icon.ico",
)

# ── Mac .app bundle ───────────────────────────────────────────────────────────
if sys.platform == "darwin":
    app = BUNDLE(
        exe,
        name="ADL Intelligence.app",
        icon=None,          # Add "adl_icon.icns" if you have one
        bundle_identifier="com.hult.adl-intelligence",
        info_plist={
            "NSHighResolutionCapable": True,
            "CFBundleShortVersionString": "1.0.0",
            "CFBundleVersion": "1.0.0",
            "CFBundleName": "ADL Intelligence",
            "NSRequiresAquaSystemAppearance": False,
        },
    )
