"""
ADL Intelligence Dashboard — Desktop Launcher
Starts the Streamlit server and opens the browser automatically.
Works both as a regular Python script and as a PyInstaller bundle.
"""

import sys
import os
import time
import threading
import subprocess
import webbrowser
import socket


def find_free_port(start=8501):
    """Find an available port starting from start."""
    for port in range(start, start + 100):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("localhost", port)) != 0:
                return port
    return start


def get_base_dir():
    """Return the directory containing the app files."""
    if getattr(sys, "frozen", False):
        # Running as PyInstaller bundle
        return os.path.dirname(sys.executable)
    else:
        # Running as plain Python script
        return os.path.dirname(os.path.abspath(__file__))


def open_browser(port, delay=3.0):
    """Open browser after a short delay to let Streamlit start."""
    time.sleep(delay)
    webbrowser.open(f"http://localhost:{port}")


def main():
    base = get_base_dir()
    dashboard = os.path.join(base, "adl_dashboard_v3.py")
    port = find_free_port(8501)

    # When frozen, streamlit is bundled — find its entry point
    if getattr(sys, "frozen", False):
        # PyInstaller puts packages in sys._MEIPASS
        meipass = getattr(sys, "_MEIPASS", base)
        streamlit_run = os.path.join(meipass, "streamlit", "__main__.py")
        cmd = [sys.executable, streamlit_run, "run", dashboard,
               "--server.port", str(port),
               "--server.headless", "true",
               "--browser.gatherUsageStats", "false",
               "--theme.base", "dark"]
    else:
        # Running normally — use streamlit from PATH / venv
        cmd = [sys.executable, "-m", "streamlit", "run", dashboard,
               "--server.port", str(port),
               "--server.headless", "true",
               "--browser.gatherUsageStats", "false",
               "--theme.base", "dark"]

    # Open browser in background thread
    t = threading.Thread(target=open_browser, args=(port,), daemon=True)
    t.start()

    print(f"\n🔷 ADL Intelligence Dashboard")
    print(f"   Starting on http://localhost:{port}")
    print(f"   Close this window to stop the dashboard.\n")

    # Start Streamlit (blocks until the server is killed)
    try:
        subprocess.run(cmd, cwd=base, check=False)
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
    except Exception as e:
        print(f"\nError starting dashboard: {e}")
        print("Try running manually:")
        print(f"  streamlit run adl_dashboard_v3.py --server.port {port}")
        input("\nPress Enter to exit...")


if __name__ == "__main__":
    main()
