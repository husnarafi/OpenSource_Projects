@echo off
REM ─────────────────────────────────────────────────────────────────
REM ADL Intelligence Dashboard — Windows Build Script
REM Produces: dist\ADL Intelligence\ADL Intelligence.exe
REM
REM Usage: Double-click build_windows.bat
REM        OR run from Command Prompt: build_windows.bat
REM ─────────────────────────────────────────────────────────────────

echo.
echo 🔷 ADL Intelligence — Windows Build
echo =====================================
echo.

REM ── Step 1: Check Python ──────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python not found.
    echo    Download from https://python.org
    echo    Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
echo ✓ Python found
for /f "tokens=*" %%i in ('python --version') do echo   %%i

REM ── Step 2: Create virtual environment ───────────────────────────
if not exist "build_env" (
    echo → Creating virtual environment...
    python -m venv build_env
)
call build_env\Scripts\activate.bat
echo ✓ Virtual environment active

REM ── Step 3: Install dependencies ──────────────────────────────────
echo → Installing dependencies (this takes 3-5 minutes)...
pip install --quiet --upgrade pip
pip install --quiet streamlit plotly pandas numpy openpyxl pyinstaller pyarrow
echo ✓ Dependencies installed

REM ── Step 4: Check data folder ─────────────────────────────────────
if not exist "data" (
    echo.
    echo ⚠️  No 'data' folder found.
    echo    Create a folder called 'data' here and copy in:
    echo      career_search_trends.csv
    echo      trends_firm_careers.csv
    echo      trends_consulting_vs_ai.csv
    echo      trends_skill_demand.csv
    echo      trends_junior_experience.csv
    echo      ADL_Alumni_Career_Destinations.xlsx
    echo      Consulting_Entry_Level_Headcount_Analysis.xlsx
    echo.
    pause
)

REM ── Step 5: Clean previous build ──────────────────────────────────
echo → Cleaning previous build...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
echo ✓ Clean

REM ── Step 6: Run PyInstaller ───────────────────────────────────────
echo → Building app (5-15 minutes on Windows)...
pyinstaller adl_dashboard.spec --noconfirm --clean

REM ── Step 7: Verify output ─────────────────────────────────────────
if exist "dist\ADL Intelligence\ADL Intelligence.exe" (
    echo.
    echo ✅ BUILD SUCCESSFUL
    echo.
    echo    Output: dist\ADL Intelligence\ADL Intelligence.exe
    echo.
    echo    To run: double-click ADL Intelligence.exe in dist\ADL Intelligence\
    echo.
    echo    To share: zip the entire 'dist\ADL Intelligence' folder
    echo    The recipient needs the whole folder, not just the .exe
    echo.
) else (
    echo.
    echo ❌ Build failed — check output above for errors
    echo.
    echo    Common fixes:
    echo    • Run as Administrator
    echo    • Disable antivirus temporarily during build
    echo    • Make sure all data files are in the data\ folder
    echo.
)

call build_env\Scripts\deactivate.bat
pause
