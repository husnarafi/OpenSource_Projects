#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# ADL Intelligence Dashboard — Mac Build Script
# Produces: dist/ADL Intelligence.app
#
# Usage:
#   chmod +x build_mac.sh
#   ./build_mac.sh
# ─────────────────────────────────────────────────────────────────

set -e

echo ""
echo "🔷 ADL Intelligence — Mac Build"
echo "================================"
echo ""

# ── Step 1: Check Python ──────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "❌ Python 3 not found. Install from https://python.org"
    exit 1
fi
echo "✓ Python: $(python3 --version)"

# ── Step 2: Create / activate virtual environment ─────────────────
if [ ! -d "build_env" ]; then
    echo "→ Creating virtual environment..."
    python3 -m venv build_env
fi
source build_env/bin/activate
echo "✓ Virtual environment active"

# ── Step 3: Install dependencies ──────────────────────────────────
echo "→ Installing dependencies (this takes 2–3 minutes)..."
pip install --quiet --upgrade pip
pip install --quiet \
    streamlit \
    plotly \
    pandas \
    numpy \
    openpyxl \
    pyinstaller \
    pyarrow

echo "✓ Dependencies installed"

# ── Step 4: Prepare data folder ───────────────────────────────────
echo "→ Checking data folder..."
if [ ! -d "data" ]; then
    echo ""
    echo "  ⚠️  No 'data/' folder found."
    echo "  Create a folder called 'data' in this directory and copy in:"
    echo "    • career_search_trends.csv"
    echo "    • trends_firm_careers.csv"
    echo "    • trends_consulting_vs_ai.csv"
    echo "    • trends_skill_demand.csv"
    echo "    • trends_junior_experience.csv"
    echo "    • ADL_Alumni_Career_Destinations.xlsx"
    echo "    • Consulting_Entry_Level_Headcount_Analysis.xlsx"
    echo ""
    read -p "  Press Enter once data/ folder is ready, or Ctrl+C to cancel..."
fi
echo "✓ Data folder: $(ls data/ | wc -l | tr -d ' ') files"

# ── Step 5: Clean previous build ──────────────────────────────────
echo "→ Cleaning previous build..."
rm -rf dist build __pycache__
echo "✓ Clean"

# ── Step 6: Run PyInstaller ───────────────────────────────────────
echo "→ Building app (5–10 minutes)..."
pyinstaller adl_dashboard.spec --noconfirm --clean 2>&1 | grep -E "(INFO|ERROR|WARNING|Building)" || true

# ── Step 7: Verify output ─────────────────────────────────────────
if [ -d "dist/ADL Intelligence.app" ]; then
    echo ""
    echo "✅ BUILD SUCCESSFUL"
    echo ""
    echo "   Output: dist/ADL Intelligence.app"
    echo "   Size:   $(du -sh 'dist/ADL Intelligence.app' | cut -f1)"
    echo ""
    echo "   To run: double-click 'ADL Intelligence.app' in Finder"
    echo "   Or:     open 'dist/ADL Intelligence.app'"
    echo ""
    echo "   To share: zip the .app file and send it"
    echo "   zip -r 'ADL_Intelligence_Mac.zip' 'dist/ADL Intelligence.app'"
    echo ""
else
    echo ""
    echo "❌ Build failed — check output above for errors"
    echo ""
    echo "   Common fixes:"
    echo "   • Run: pip install pyinstaller --upgrade"
    echo "   • Check all data files are in the data/ folder"
    echo "   • On Apple Silicon Mac, try: arch -x86_64 ./build_mac.sh"
    exit 1
fi

deactivate
