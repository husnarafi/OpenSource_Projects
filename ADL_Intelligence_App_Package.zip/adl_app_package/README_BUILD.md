# ADL Intelligence Dashboard — Desktop App Build Guide

**Built by Husna Rafi for Arthur D. Little | Hult MBA Capstone 2026**

This package converts the Streamlit dashboard into a standalone desktop application.
No Python installation required on the recipient's machine.

---

## What You Get

| Platform | Output | Size |
|----------|--------|------|
| Mac | `ADL Intelligence.app` — double-click to open | ~350–500 MB |
| Windows | `ADL Intelligence.exe` + folder — double-click .exe | ~400–600 MB |

The app opens a browser tab automatically and runs entirely on the user's machine.
No internet required after download (except for the Google Fonts in CSS — minor).

---

## Folder Structure Required Before Building

```
📁 adl-app/                        ← this folder
├── adl_dashboard_v3.py            ← the dashboard
├── launcher.py                    ← app launcher
├── adl_dashboard.spec             ← PyInstaller config
├── build_mac.sh                   ← Mac build script
├── build_windows.bat              ← Windows build script
├── README_BUILD.md                ← this file
└── 📁 data/                       ← ALL DATA FILES GO HERE
    ├── career_search_trends.csv
    ├── trends_firm_careers.csv
    ├── trends_consulting_vs_ai.csv
    ├── trends_skill_demand.csv
    ├── trends_junior_experience.csv
    ├── ADL_Alumni_Career_Destinations.xlsx
    └── Consulting_Entry_Level_Headcount_Analysis.xlsx
```

**The `data/` folder is critical.** Create it and copy all 7 files into it before building.

---

## Build Instructions — Mac

### Requirements
- Mac OS 12 (Monterey) or later
- Python 3.10+ installed (from https://python.org — NOT the Apple system Python)

### Steps

```bash
# 1. Open Terminal
# 2. Navigate to the adl-app folder
cd ~/Downloads/adl-app

# 3. Make the build script executable
chmod +x build_mac.sh

# 4. Run it
./build_mac.sh
```

The script handles everything: virtual environment, dependencies, and building.

### Output
```
dist/ADL Intelligence.app
```

Double-click it. It opens a browser tab automatically at `localhost:8501`.

### To Share the Mac App
```bash
zip -r ADL_Intelligence_Mac.zip "dist/ADL Intelligence.app"
```
Send the zip. Recipients double-click the .app — no Python needed.

### Apple Silicon (M1/M2/M3) Note
If you get architecture errors, try:
```bash
arch -x86_64 ./build_mac.sh
```

---

## Build Instructions — Windows

### Requirements
- Windows 10 or 11
- Python 3.10+ from https://python.org
  - ✅ Check **"Add Python to PATH"** during installation

### Steps

1. Copy the `adl-app` folder to your Windows machine
2. Create the `data\` subfolder and copy all 7 data files into it
3. Double-click `build_windows.bat`

Or from Command Prompt:
```cmd
cd C:\Users\YourName\Downloads\adl-app
build_windows.bat
```

### Output
```
dist\ADL Intelligence\ADL Intelligence.exe
```

Double-click the `.exe`. It opens a browser tab automatically.

### To Share the Windows App
Zip the **entire** `dist\ADL Intelligence\` folder — not just the `.exe`.
The `.exe` needs the files next to it to run.

```cmd
powershell Compress-Archive -Path "dist\ADL Intelligence" -DestinationPath "ADL_Intelligence_Windows.zip"
```

---

## What Happens When Someone Opens the App

1. They double-click the `.app` or `.exe`
2. A terminal window briefly appears (Windows) or flashes (Mac)
3. After 3 seconds, their default browser opens at `http://localhost:8501`
4. The dashboard loads and runs fully locally — no internet needed for data
5. They close the browser tab when done (the app continues running in background)
6. To fully stop: close the terminal/dock icon on Mac, or close the Command Prompt on Windows

---

## Fastest Alternative — If Building Takes Too Long

If PyInstaller build fails or takes too long, share the **Streamlit Cloud** version instead:

1. Push the `adl-app` folder to a GitHub repository
2. Go to https://share.streamlit.io
3. Sign in with GitHub
4. Select the repo and `adl_dashboard_v3.py`
5. Get a public URL in 2 minutes — anyone clicks it, no install needed

---

## Troubleshooting

**Build fails with "ModuleNotFoundError"**
```bash
pip install streamlit plotly pandas numpy openpyxl pyarrow --upgrade
```

**App opens but shows "FileNotFoundError"**
The `data/` folder is missing or has wrong filenames. Check all 7 files are present with exact names.

**Windows Defender blocks the .exe**
PyInstaller executables sometimes trigger false positives.
Click "More info" → "Run anyway" in the Windows SmartScreen warning.

**Mac shows "cannot be opened because the developer cannot be verified"**
```bash
xattr -d com.apple.quarantine "dist/ADL Intelligence.app"
```
Or: right-click → Open → Open anyway.

**Browser opens but shows an error page**
Wait 10 seconds and refresh. Streamlit takes a moment to start on first launch.

---

## Files in This Package

| File | Purpose |
|------|---------|
| `adl_dashboard_v3.py` | Main dashboard — all 15 pages |
| `launcher.py` | Starts Streamlit and opens browser |
| `adl_dashboard.spec` | PyInstaller build configuration |
| `build_mac.sh` | One-click Mac build script |
| `build_windows.bat` | One-click Windows build script |
| `data/` | All data files (you copy these in) |

---

*Built by Husna Rafi · hrafi@student.hult.edu · Hult International Business School · April 2026*
